
function accept() {
    let arr = [];
    for(i=0;i<4;i++){
        var pr = prompt('enter a number');
        arr.push(parseInt(pr));
    }
    min(...arr);
    
}

function min(...numbers){
    console.log(numbers);
    min = numbers[0];
    for(i=1;i<numbers.length;i++){
        if(min > numbers[i]){ //55>33
            min = numbers[i]; //min=33
        }
    }
    console.log(min);
}

accept();
